Compare the current layout with the design (in folder "design") and make sure that the layout looks like the design (mobile and desktop).

Hints <br>
- Remove the horizontal scrollbar in Desktop: use the inspector to find out what is causing it
- How does the grid have to be changed to look like the mobile layout?
- Are all the other styles in sync with the layout?

Estimated time: 30 minutes <br>
Total points: 30
