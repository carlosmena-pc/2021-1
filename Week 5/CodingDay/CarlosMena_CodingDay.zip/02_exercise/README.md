Create the template with fixed width sidebars and fluid central column.
Make it responsive.

Estimated time: 45 minutes <br>
Total points: 45
